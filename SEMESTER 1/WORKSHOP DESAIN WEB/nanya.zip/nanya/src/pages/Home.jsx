import React from 'react'
import { data } from '../Data'
import Product from '../component/Product'

function Home() {
  return (
    <div className='container mx-auto my-4'>
      <div className='row row-cols-1 row-cols-sm-2 row-cols-md-4 g-3'>
         {data.map((data, key) => <Product key={key} data={data}/>)}
      </div> 
    </div>
  )
}

export default Home